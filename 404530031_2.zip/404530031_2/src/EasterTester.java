import java.util.Scanner;

public class EasterTester
{
	public static void main(String args[])
	{
		Scanner in = new Scanner(System.in);
		while (true)
		{
			System.out.print("Please enter a year: ");
			int year = in.nextInt();
			String result = Easter.calculateEaster(year);
			System.out.print(result);
		}
	}
}
