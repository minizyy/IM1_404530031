package bank;
import java.util.ArrayList;
/**
 * A bank account has a balance that can be changed by deposits and withdrawals.
 */
public class BankAccount
{
	private int accountNumber;
	private double balance;
	final String OPEN = "open";
	final String SUSPENDED = "suspended";
	final String CLOSED = "closed";
	private String accountState;
	ArrayList<Double> transactions = new ArrayList();

	/**
	 * Constructs a bank account with a zero balance.
	 * @param anAccountNumber the account number for this account
	 */
	public BankAccount(int anAccountNumber)
	{
		accountNumber = anAccountNumber;
		accountState = OPEN;
		balance = 0;
	}
	
	/**
	 * Constructs a bank account with a given balance.
	 * @param anAccountNumber the account number for this account
	 * @param initialBalance the initial balance
	 */
	public BankAccount(int anAccountNumber, double initialBalance)
	{
		accountNumber = anAccountNumber;
		accountState = OPEN;
		balance = 0;
		if (initialBalance > 0)
		{
			deposit(initialBalance);
		}
	}
	
	/**
	 * Gets the account number of this account.
	 * @return the account number
	 */
	public int getAccountNumber()
	{
		return accountNumber;
	}
	
	/**
	 * Deposits money into the bank account.
	 * @param amount the amount to deposit
	 */
	public void deposit(double amount)
	{
		if (accountState.equals(OPEN) && amount > 0)
		{
			double newBalance = balance + amount;
			balance = newBalance;
			addTransaction(amount);
		}
	}
	
	/**
	 * Withdraws money from the bank account.
	 * @param amount the amount to withdraw
	 */
	public void withdraw(double amount)
	{
		if (accountState.equals(OPEN) && (amount > 0 && amount <= balance))
		{
			double newBalance = balance - amount;
			balance = newBalance;
			addTransaction(-amount);
		}
	}
	
	/**
	 * ����b��
	 */
	public void suspend()
	{
		if (isOpen())
		{
			setStatus(SUSPENDED);
		}
	}
	
	/**
	 * �����b��
	 */
	public void close()
	{
		if (!isClosed())
		{
			withdraw(balance);
			setStatus(CLOSED);
		}
	}
	
	/**
	 * �A���ҥαb��
	 */
	public void reOpen()
	{
		if (isSuspended())
		{
			setStatus(OPEN);
		}
	}
	
	/**
	 * �T�{�b��O�_���}�Ҫ��A
	 * @return �}�һP�_
	 */
	public boolean isOpen()
	{
		return accountState.equals(OPEN);
	}
	
	/**
	 * �T�{�b��O�_������A
	 * @return ����P�_
	 */
	public boolean isSuspended()
	{
		return accountState.equals(SUSPENDED);
	}
	
	/**
	 * �T�{�b�᪬�A�O�_������
	 * @return �����P�_
	 */
	public boolean isClosed()
	{
		return accountState.equals(CLOSED);
	}
	
	/**
	 * �W�[�������
	 * @param amount ���Ȫ��ܦs�ڡA�t�Ȫ��ܴ���
	 */
	public void addTransaction(double amount)
	{
		transactions.add(amount);
	}
	
	/**
	 * ���o�b��������
	 * @return �r��Φ����b��s�ڻP���ڬ���
	 */
	public String getTransactions()
	{
		String result = "Account #" + accountNumber + " transactions:\n\n";
		int counter = 1;
		for (double element: transactions)
		{
			result += (counter + ": " + element + "\n");
			counter++;
		}
		result += "End of transactions\n\n\n";
		return result;
	}
	
	/**
	 * ���o�b�᪺���ĥ������
	 * @return �������
	 */
	public int retrieveNumberOfTransactions()
	{
		return transactions.size();
	}
	
	/**
	 * Gets the current balance of the bank account.
	 * @return the current balance
	 */
	public double getBalance()
	{
		return balance;
	}
	
	/**
	 * ���o�b�᪺���A
	 * @return �b�᪬�A
	 */
	public String getAccountStatus()
	{
		return accountState;
	}
	
	/**
	 * �]�w�b�᪬�A
	 * @param status ���]�w�����A
	 */
	private void setStatus(String status)
	{
		if (status.equals(OPEN))
		{
			accountState = OPEN;
		}
		else if (status.equals(SUSPENDED))
		{
			accountState = SUSPENDED;
		}
		else
		{
			accountState = CLOSED;
		}
	}
}
